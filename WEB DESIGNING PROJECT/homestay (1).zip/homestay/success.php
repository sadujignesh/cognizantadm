<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .a{
            display: inline-block;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
<body style="background-color: rgba(189, 250, 250, 0.801)">

<h1 class="a" style='color:blue; margin-top: 300px;'>You have Successfully booked this room</h1>
<br>
<h2 class="a" ><a href='index.php'>Back to Home</a></h2>
</body>
</html>