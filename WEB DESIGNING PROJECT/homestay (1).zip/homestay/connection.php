
<?php

$con=mysqli_connect("localhost","root","","homestay") or die('DATABASE connection failed');

?>
